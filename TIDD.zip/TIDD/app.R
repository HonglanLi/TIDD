# Run the application
shinyApp(ui = ui, server = server, display.mode="showcase")